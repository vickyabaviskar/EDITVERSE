package com.editverse.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {
    private var selectedVideo by mutableStateOf<Uri?>(null)
    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            selectedVideo = uri
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFB58CFF),
                background = Color(0xFF101014),
                surface = Color(0xFF1B1B23)
            )) {
                EditVerseScreen(
                    selectedVideo = selectedVideo,
                    onPickVideo = { videoPicker.launch(arrayOf("video/*")) }
                )
            }
        }
    }
}

@Composable
private fun EditVerseScreen(selectedVideo: Uri?, onPickVideo: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(selectedVideo) {
        if (selectedVideo != null) {
            player.setMediaItem(MediaItem.fromUri(selectedVideo))
            player.prepare()
        }
    }

    var titleText by remember { mutableStateOf("Your next video starts here") }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF101014)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("EDITVERSE", color = Color(0xFFB58CFF), fontSize = 27.sp)
            Text("Video + Typography Studio", color = Color.White, fontSize = 16.sp)
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF20202A), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (selectedVideo != null) {
                    AndroidView(
                        factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text("Import a video to preview", color = Color.LightGray)
                }
            }
            Button(onClick = onPickVideo, modifier = Modifier.fillMaxWidth()) {
                Text("Import video")
            }
            OutlinedTextField(
                value = titleText,
                onValueChange = { titleText = it },
                label = { Text("Typography text") },
                modifier = Modifier.fillMaxWidth()
            )
            Text("Timeline", color = Color.White, fontSize = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Video", "Text", "Audio").forEach {
                    Surface(color = Color(0xFF292936), shape = RoundedCornerShape(8.dp)) {
                        Text(it, color = Color.White, modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
                    }
                }
            }
            Text("Starter build 0.1.0 • Editing and export features are not implemented yet",
                color = Color.Gray, fontSize = 11.sp)
        }
    }
}
