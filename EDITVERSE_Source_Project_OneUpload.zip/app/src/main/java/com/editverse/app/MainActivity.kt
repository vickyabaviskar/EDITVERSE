package com.editverse.app

import android.content.Intent
import android.net.Uri
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.Composition
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.min

private val Bg = Color(0xFF101014)
private val Panel = Color(0xFF20202A)
private val Purple = Color(0xFFB58CFF)
private val Muted = Color(0xFFAAA7B4)

class MainActivity : ComponentActivity() {
    private var selectedVideo by mutableStateOf<Uri?>(null)

    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {
                // Some document providers do not offer persistable permissions.
            }
            selectedVideo = uri
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Purple,
                background = Bg,
                surface = Panel
            )) {
                EditVerseScreen(
                    selectedVideo = selectedVideo,
                    onPickVideo = { videoPicker.launch(arrayOf("video/*")) }
                )
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun EditVerseScreen(selectedVideo: Uri?, onPickVideo: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var durationMs by remember { mutableLongStateOf(0L) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var trimStartMs by remember { mutableLongStateOf(0L) }
    var trimEndMs by remember { mutableLongStateOf(0L) }
    var titleText by remember { mutableStateOf("Your next video starts here") }
    var splitMarkers by remember { mutableStateOf(listOf<Long>()) }
    var activeTrack by remember { mutableStateOf("Video") }
    var exportStatus by remember { mutableStateOf("Ready to export") }
    var exporting by remember { mutableStateOf(false) }

    LaunchedEffect(selectedVideo) {
        if (selectedVideo != null) {
            player.stop()
            player.clearMediaItems()
            player.setMediaItem(MediaItem.fromUri(selectedVideo))
            player.prepare()
            splitMarkers = emptyList()
            trimStartMs = 0L
            trimEndMs = 0L
        }
    }

    LaunchedEffect(player, selectedVideo) {
        while (true) {
            val d = player.duration
            if (d > 0) {
                durationMs = d
                if (trimEndMs == 0L || trimEndMs > d) trimEndMs = d
            }
            positionMs = max(0L, player.currentPosition)
            delay(200)
        }
    }

    val safeDuration = max(1L, durationMs)
    val progress = (positionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
    val trimStartFraction = (trimStartMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
    val trimEndFraction = (trimEndMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(
            modifier = Modifier.fillMaxSize().systemBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("EDITVERSE", color = Purple, fontSize = 29.sp, fontWeight = FontWeight.Bold)
            Text("Video + Typography Studio", color = Color.White, fontSize = 16.sp)

            Box(
                modifier = Modifier.fillMaxWidth().height(330.dp)
                    .background(Color(0xFF08080B), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (selectedVideo != null) {
                    AndroidView(
                        factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                        update = { it.player = player },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text("Import a video to preview", color = Muted)
                }
            }

            Button(
                onClick = onPickVideo,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Color(0xFF21152F))
            ) {
                Text(if (selectedVideo == null) "Import video" else "Change video")
            }

            Text("TIMELINE", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()) {
                Text(formatTime(positionMs), color = Purple, fontWeight = FontWeight.Bold)
                Text("${formatTime(durationMs)} total", color = Muted, fontSize = 12.sp)
            }
            Slider(
                value = progress,
                onValueChange = { fraction ->
                    if (durationMs > 0) {
                        val target = (fraction * durationMs).toLong()
                        player.seekTo(target)
                        positionMs = target
                    }
                },
                enabled = selectedVideo != null && durationMs > 0,
                colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
            )

            Text("TRACKS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Video", "Text", "Audio").forEach { track ->
                    FilterChip(
                        selected = activeTrack == track,
                        onClick = { activeTrack = track },
                        label = { Text(track) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Purple,
                            selectedLabelColor = Color(0xFF21152F)
                        )
                    )
                }
            }

            // Timeline lanes: visual clip strip plus independently selectable text/audio lanes.
            Column(
                modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("00:00        00:10        00:20        00:30        00:40", color = Muted, fontSize = 10.sp)
                TrackLane("VIDEO", if (selectedVideo != null) "Imported clip" else "No video", Color(0xFF4F8FCE))
                TrackLane("TEXT", if (titleText.isBlank()) "Empty text layer" else titleText, Purple)
                TrackLane("AUDIO", "Add audio in a later update", Color(0xFF4CBA91))
            }

            Text("TRIM RANGE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("Start: ${formatTime(trimStartMs)}", color = Muted, fontSize = 12.sp)
            Slider(
                value = trimStartFraction,
                onValueChange = { f ->
                    val newStart = (f * safeDuration).toLong()
                    trimStartMs = min(newStart, max(0L, trimEndMs - 500L))
                    if (positionMs < trimStartMs) player.seekTo(trimStartMs)
                },
                enabled = selectedVideo != null && durationMs > 0,
                colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
            )
            Text("End: ${formatTime(trimEndMs)}", color = Muted, fontSize = 12.sp)
            Slider(
                value = trimEndFraction,
                onValueChange = { f ->
                    val newEnd = (f * safeDuration).toLong()
                    trimEndMs = max(newEnd, min(safeDuration, trimStartMs + 500L))
                },
                enabled = selectedVideo != null && durationMs > 0,
                colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        if (selectedVideo != null && positionMs > 0L && positionMs < durationMs) {
                            splitMarkers = (splitMarkers + positionMs).distinct().sorted()
                        }
                    },
                    enabled = selectedVideo != null && durationMs > 1000L && positionMs > 0L && positionMs < durationMs,
                    modifier = Modifier.weight(1f)
                ) { Text("＋ Set split point") }
                OutlinedButton(
                    onClick = {
                        trimStartMs = 0L
                        trimEndMs = durationMs
                        player.seekTo(0L)
                        splitMarkers = emptyList()
                    },
                    enabled = selectedVideo != null && durationMs > 0,
                    modifier = Modifier.weight(1f)
                ) { Text("Reset") }
            }

            Button(
                onClick = {
                    val uri = selectedVideo
                    if (uri != null && durationMs > 0L && trimEndMs > trimStartMs) {
                        exporting = true
                        exportStatus = "Preparing trimmed video…"
                        exportVideoSegments(context, uri, listOf(trimStartMs to trimEndMs), "EDITVERSE_Trim") { message, done ->
                            exportStatus = message
                            exporting = !done
                        }
                    }
                },
                enabled = selectedVideo != null && durationMs > 0L && trimEndMs > trimStartMs && !exporting,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Color(0xFF21152F))
            ) { Text(if (exporting) "Exporting…" else "Export trimmed MP4") }

            Button(
                onClick = {
                    val uri = selectedVideo
                    val cut = positionMs
                    if (uri != null && cut > 500L && cut < durationMs - 500L) {
                        exporting = true
                        exportStatus = "Preparing both split clips…"
                        exportVideoSegments(context, uri, listOf(0L to cut, cut to durationMs), "EDITVERSE_Split") { message, done ->
                            exportStatus = message
                            exporting = !done
                        }
                    }
                },
                enabled = selectedVideo != null && durationMs > 1000L && positionMs > 500L && positionMs < durationMs - 500L && !exporting,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export 2 clips at playhead") }
            Text(exportStatus, color = if (exportStatus.startsWith("Saved")) Color(0xFF70D6A5) else Muted, fontSize = 12.sp)

            if (splitMarkers.isNotEmpty()) {
                Text("Split markers: ${splitMarkers.joinToString("  •  ") { formatTime(it) }}",
                    color = Purple, fontSize = 11.sp)
            }

            OutlinedTextField(
                value = titleText,
                onValueChange = { titleText = it },
                label = { Text("Typography text layer") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple,
                    focusedLabelColor = Purple,
                    cursorColor = Purple
                )
            )

            Text("Made by Vickya Baviskar", color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth())
            Text(
                "EDITVERSE 0.3 • Real trim export and split-into-two MP4 export. Text, audio, effects and multi-clip timeline editing are planned for later versions.",
                color = Muted,
                fontSize = 10.sp
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun TrackLane(label: String, content: String, tint: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 42.dp)
            .background(Color(0xFF15151C), RoundedCornerShape(8.dp)).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = tint, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(54.dp))
        Box(
            modifier = Modifier.weight(1f).height(26.dp)
                .background(tint.copy(alpha = 0.22f), RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(content, color = Color.White, fontSize = 10.sp, maxLines = 1)
        }
    }
}

private fun formatTime(ms: Long): String {
    val safe = max(0L, ms)
    val totalSeconds = safe / 1000L
    return "%02d:%02d".format(totalSeconds / 60L, totalSeconds % 60L)
}


@OptIn(UnstableApi::class)
private fun exportVideoSegments(
    context: android.content.Context,
    source: Uri,
    segments: List<Pair<Long, Long>>,
    namePrefix: String,
    onStatus: (String, Boolean) -> Unit
) {
    val appContext = context.applicationContext
    val outputDir = File(appContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "EDITVERSE")
    if (!outputDir.exists() && !outputDir.mkdirs()) {
        onStatus("Could not create export folder", true)
        return
    }

    fun runSegment(index: Int) {
        if (index >= segments.size) {
            onStatus("Saved ${segments.size} MP4 file(s) to Movies/EDITVERSE", true)
            return
        }
        val (startMs, endMs) = segments[index]
        if (endMs <= startMs) {
            onStatus("Invalid trim range", true)
            return
        }
        val outputFile = File(outputDir, "${namePrefix}_${System.currentTimeMillis()}_${index + 1}.mp4")
        val mediaItem = androidx.media3.common.MediaItem.Builder()
            .setUri(source)
            .setClippingConfiguration(
                androidx.media3.common.MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            ).build()
        val editedItem = EditedMediaItem.Builder(mediaItem).build()
        val transformer = Transformer.Builder(appContext)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    try {
                        val values = ContentValues().apply {
                            put(MediaStore.Video.Media.DISPLAY_NAME, outputFile.name)
                            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                            if (android.os.Build.VERSION.SDK_INT >= 29) {
                                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/EDITVERSE")
                                put(MediaStore.Video.Media.IS_PENDING, 1)
                            }
                        }
                        val collection = if (android.os.Build.VERSION.SDK_INT >= 29) {
                            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        } else {
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        }
                        val savedUri = appContext.contentResolver.insert(collection, values)
                            ?: throw IllegalStateException("MediaStore could not create output")
                        appContext.contentResolver.openOutputStream(savedUri).use { output ->
                            if (output == null) throw IllegalStateException("Could not open output stream")
                            outputFile.inputStream().use { input -> input.copyTo(output) }
                        }
                        if (android.os.Build.VERSION.SDK_INT >= 29) {
                            val ready = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                            appContext.contentResolver.update(savedUri, ready, null, null)
                        }
                        outputFile.delete()
                        if (index + 1 < segments.size) {
                            onStatus("Clip ${index + 1} saved. Exporting clip ${index + 2}…", false)
                            runSegment(index + 1)
                        } else {
                            onStatus("Saved ${segments.size} MP4 file(s) in Movies/EDITVERSE", true)
                        }
                    } catch (error: Exception) {
                        onStatus("Export finished but saving failed: ${error.message ?: "unknown error"}", true)
                    }
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    outputFile.delete()
                    onStatus("Export failed: ${exportException.message ?: "unsupported video format"}", true)
                }
            }).build()
        onStatus("Exporting clip ${index + 1}/${segments.size}…", false)
        try {
            transformer.start(editedItem, outputFile.absolutePath)
        } catch (error: Exception) {
            outputFile.delete()
            onStatus("Could not start export: ${error.message ?: "unknown error"}", true)
        }
    }
    runSegment(0)
}
