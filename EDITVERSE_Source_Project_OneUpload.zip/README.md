# EDITVERSE Android starter

This is an early Android Studio project shell. It currently provides a Compose interface, video file picker, Media3 playback preview, and a typography text field.

It is not a complete video editor yet. Trimming, multi-track editing, animated typography, effects, audio mixing, and video export are future implementation tasks.

## Build
Use Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17, and Gradle 8.9 or newer compatible Gradle 8.x.
