# EDITVERSE v0.3.0

Android video editor prototype built with Kotlin, Jetpack Compose and AndroidX Media3.

## v0.3 features
- Import a video from device storage and preview/play it.
- Seek through the source video.
- Select a start/end range and export that range as an MP4.
- Set the playhead as a split point and export the two resulting segments as separate MP4 files.
- Exported files are added to the device MediaStore under Movies/EDITVERSE.
- Includes the app version and creator attribution in the editor UI.

## Build
Open this project in Android Studio, or use the repository GitHub Actions workflow to build the debug APK.

## Current limitations
This is an incremental prototype, not a finished CapCut replacement. The split operation creates two separate exported MP4 files; it does not yet create editable clips on a multi-clip timeline. Text is currently an editable UI layer and is not burned into the exported video. Audio editing, transitions, effects, filters, captions, project save/load, undo/redo and advanced timeline interactions are not implemented yet.
