# EDITVERSE 0.2 — Timeline Preview

This is an incremental Android starter project. It adds a working preview timeline with:
- video import and playback using AndroidX Media3
- playhead seeking
- start/end range controls for selecting a section
- split-marker placement at the current playhead
- editable typography text layer preview

Important: this version does **not** yet render/export trimmed clips, combine multiple video clips, mix audio tracks, or apply effects. The trim range and split markers are editing controls/prototypes, not a final rendered edit.

Build with the repository's GitHub Actions workflow. The workflow expects this ZIP at the repository root as `EDITVERSE_Source_Project_OneUpload.zip`.
